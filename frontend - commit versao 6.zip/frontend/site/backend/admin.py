from django.contrib import admin
from .models import QrCodes, Classes, Students

admin.site.register(QrCodes)
admin.site.register(Classes)
admin.site.register(Students)
